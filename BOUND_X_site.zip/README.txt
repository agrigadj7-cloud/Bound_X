BOUND X website
================

Files:
- index.html
- style.css
- script.js
- cover.png

Discord:
- BOUND X: https://discord.gg/Vs2Dr6ataj
- RMRP official Discord: https://discord.com/invite/6Az63EPEAA

Open index.html in a browser. No build step is required.
